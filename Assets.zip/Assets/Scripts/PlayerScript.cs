using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerScript : MonoBehaviour {

    public float playerMovementSpeed = 5.8f;

    //0 = burger 1 = fry 2 = soda = 3
    //0 is default;
    public int menuStationItem = -1;

    // Start is called before the first frame update
    void Start() {

        
    }


    // Update is called once per frame
    void Update() {

        //clamp player position
        Vector2 currentPosition = transform.position;
        currentPosition.x = Mathf.Clamp( currentPosition.x , -5.2f, 5.2f);
        transform.position = currentPosition;

        if (Input.GetKey(KeyCode.LeftArrow)) {

            transform.Translate(Vector2.left * playerMovementSpeed * Time.deltaTime);
        }

        if (Input.GetKey(KeyCode.RightArrow)) {

            transform.Translate(Vector2.right * playerMovementSpeed * Time.deltaTime);

        }
    }

    void OnCollisionStay2D(Collision2D collision) {


         if (collision.gameObject.tag == "BurgerStation") {

            //Debug.Log("burger station ready!");
            menuStationItem = 0;
        } 

        if (collision.gameObject.tag == "FryStation") {

            //Debug.Log("fry station ready!");
            menuStationItem = 1;

        }

        if (collision.gameObject.tag == "SodaStation") {

            //Debug.Log("soda station ready!");
            menuStationItem = 2;
        }


    }

    void OnCollisionExit2D(Collision2D collision) {


        menuStationItem = -1;

    }


}
