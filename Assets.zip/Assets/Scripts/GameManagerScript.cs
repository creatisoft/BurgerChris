using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class GameManagerScript : MonoBehaviour {


    public TextMeshProUGUI playerScoreText;
    private int playerScore = 0;

    // Start is called before the first frame update
    void Start() {

        playerScoreText.text = "Score: " + playerScore;
        
    }


    public void AddPoint(int points) {

        playerScore = playerScore + points;
        playerScoreText.text = "Score: " + playerScore;
    }

    public void RemovePoint(int points) {

        playerScore = playerScore - points;
        playerScoreText.text = "Score: " + playerScore;
    }

    // Update is called once per frame
    void Update() {

    }

}
