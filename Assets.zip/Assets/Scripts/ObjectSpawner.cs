using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectSpawner : MonoBehaviour {


    private PlayerScript playerScript;

    public GameObject bagObject;
    public GameObject burgerObject;
    public GameObject fryObject;
    public GameObject sodaObject;

    public GameObject[] bagObjectSpawns;
    public GameObject[] burgerObjectSpawns;
    public GameObject[] fryObjectSpawns;
    public GameObject[] sodaObjectSpawns;


    private int numberOfBags = 20;
    private int numberOfBurgers = 3;
    private int numberOfFrys = 3;
    private int numberOfSoda = 3;


    public Transform bagLocation;
    public Transform burgerLocation;
    public Transform fryLocation;
    public Transform sodaLocation;

    private AudioSource aSource;
    private int foodDropSound;

    // Start is called before the first frame update



    void InitObjects(GameObject[] objList, int amount, GameObject objToSpawn) {

        for (int i = 0; i < amount; i++) {

            objList[i] = Instantiate(objToSpawn);
            objList[i].SetActive(false);

        }


    }

    void Start() {

        playerScript = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerScript>();
        aSource = gameObject.GetComponent<AudioSource>();

        /*InitObjects(bagObjectSpawns, 3, bagObject);
        for (int i = 0; i < numberOfBags; i++) {

            bagObjectSpawns[i] = Instantiate(bagObject);
            bagObjectSpawns[i].SetActive(false);

        }*/

        bagObjectSpawns = new GameObject[numberOfBags];
        InitObjects(bagObjectSpawns, numberOfBags, bagObject);

        burgerObjectSpawns = new GameObject[numberOfBurgers];
        InitObjects(burgerObjectSpawns, numberOfBurgers, burgerObject);

        fryObjectSpawns = new GameObject[numberOfFrys];
        InitObjects(fryObjectSpawns, numberOfFrys, fryObject);

        sodaObjectSpawns = new GameObject[numberOfSoda];
        InitObjects(sodaObjectSpawns, numberOfSoda, sodaObject);


        InvokeRepeating("AutoSpawnBag", 0.5f, 5.0f);

    }


    void SpawnObject(int amount, GameObject[] objToSpawn, Transform location) {

        for(int i = 0; i < amount; i++) {


            if (objToSpawn[i].activeInHierarchy == false) {

                objToSpawn[i].SetActive(true);
                objToSpawn[i].transform.position = location.position;
                //objToSpawn[i].transform.rotation = location;
                break;

            }
            

        }


    }

    void MenuStationPlayerScript() {

        switch (playerScript.menuStationItem) {

            case 0:
                if (Input.GetKeyDown(KeyCode.UpArrow)) {

                    //Debug.Log("burger drop!");

                    aSource.Play();
                    SpawnObject(numberOfBurgers, burgerObjectSpawns, burgerLocation);

                }
                break;
            case 1:
                if (Input.GetKeyDown(KeyCode.UpArrow)) {

                    //Debug.Log("fry drop!");
                    aSource.Play();
                    SpawnObject(numberOfFrys, fryObjectSpawns, fryLocation);

                }
                break;
            case 2:
                if (Input.GetKeyDown(KeyCode.UpArrow)) {

                    //Debug.Log("soda drop!");
                    aSource.Play();
                    SpawnObject(numberOfSoda, sodaObjectSpawns, sodaLocation);
                }
                break;
            default:
                break;

        }

        if (Input.GetKeyDown(KeyCode.P)) {

            SpawnObject(numberOfBags, bagObjectSpawns, bagLocation);
            //SpawnObject(numberOfBurgers, burgerObjectSpawns, burgerLocation);
            //SpawnObject(numberOfFrys, fryObjectSpawns, fryLocation);
            //SpawnObject(numberOfSoda, sodaObjectSpawns, sodaLocation);

        }



    }

    void AutoSpawnBag() {

        SpawnObject(numberOfBags, bagObjectSpawns, bagLocation);

    }


    // Update is called once per frame
    void Update() {


        MenuStationPlayerScript();
       

    }

}
