using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class FoodBagScript : MonoBehaviour {

    public float bagSpeed = 1.0f;
    private bool moveBag = true;

    public int numberOfBurger = 0;
    public int numberOfry = 0;
    public int numberOfSoda = 0;

    private GameManagerScript gmScript;
    private AudioSource aSource;
    public AudioClip[] aClips = new AudioClip[2];
    private int bagSuccess = 0;
    private int foodEnteredBag = 1;

    // Start is called before the first frame update

    void Start() {


        gmScript = GameObject.FindGameObjectWithTag("GameManager").GetComponent<GameManagerScript>();
        aSource = gameObject.GetComponent<AudioSource>();
    }


    void BagMovement() {

        transform.Translate(Vector2.right * bagSpeed * Time.deltaTime);


    }


    // Update is called once per frame
    void Update() {



        if (moveBag) {

            BagMovement();
        }


    }


    private void Reset() {

        numberOfry = 0;
        numberOfBurger = 0;
        numberOfSoda = 0;
        moveBag = true;
        bagSpeed = 1;
        gameObject.SetActive(false);

    }


    void OnCollisionEnter2D(Collision2D collision) {

        if(collision.gameObject.tag == "FoodBag") {

            //Debug.Log("did we hit?");
            moveBag = false;

            if(numberOfBurger == 1 && numberOfSoda == 1 && numberOfry == 1) {

                Debug.Log("Order Complete!");
                aSource.clip = aClips[bagSuccess];
                aSource.Play();
                gmScript.AddPoint(10);
                Invoke("Reset", 0.5f);
                //gameObject.SetActive(false);

            } else {

                bagSpeed = 1;

                Invoke("Reset", 0.0f);
                gameObject.SetActive(false);
                gmScript.RemovePoint(5);

            }

        }

        if(collision.gameObject.tag == "BurgerItem") {

            //Debug.Log("burger in the bag!");

            if (numberOfBurger == 0) {

                aSource.clip = aClips[foodEnteredBag];
                aSource.Play();
                gmScript.AddPoint(2);

            }

            numberOfBurger = numberOfBurger + 1;




            collision.gameObject.SetActive(false);

        }
        if (collision.gameObject.tag == "FryItem") {

            //Debug.Log("fry in the bag!");

            if (numberOfry == 0) {

                aSource.clip = aClips[foodEnteredBag];
                aSource.Play();
                gmScript.AddPoint(2);

            }

            numberOfry = numberOfry + 1;
            collision.gameObject.SetActive(false);

        }
        if (collision.gameObject.tag == "SodaItem") {

            //Debug.Log("soda in the bag!");

            if (numberOfSoda == 0) {

                aSource.clip = aClips[foodEnteredBag];
                aSource.Play();
                gmScript.AddPoint(2);

            }

            numberOfSoda = numberOfSoda + 1;
            collision.gameObject.SetActive(false);

        }

        if (collision.gameObject.tag == "BagSpeedUp") {

            //Debug.Log("speed up!");

            bagSpeed = bagSpeed + 1.50f;


        }


    }


}
